document.addEventListener('DOMContentLoaded', async () => {
  const inputs = [...document.querySelectorAll('input[name="gender"]')];
  const minAgeInput = document.getElementById('minAge');
  const maxAgeInput = document.getElementById('maxAge');

  // Ophalen van opgeslagen voorkeuren
  try {
    const result = await chrome.storage.sync.get(['gender', 'minAge', 'maxAge']);
    const selectedGenders = result.gender || [];
    inputs.forEach(input => {
      input.checked = selectedGenders.includes(input.value);
    });

    minAgeInput.value = result.minAge ?? 18;
    maxAgeInput.value = result.maxAge ?? 99;
  } catch (err) {
    console.error('Fout bij ophalen voorkeuren:', err);
  }

  // Opslaan bij wijziging (genders)
  const handleGenderChange = async () => {
    const preferredGenders = inputs
      .filter(input => input.checked)
      .map(input => input.value);

    try {
      await chrome.storage.sync.set({ gender: preferredGenders });
      console.log('Voorkeursgeslachten opgeslagen:', preferredGenders);
    } catch (err) {
      console.error('Fout bij opslaan voorkeuren:', err);
    }
  };
  inputs.forEach(input => input.addEventListener('change', handleGenderChange));

  // Opslaan bij wijziging (leeftijd)
  const handleAgeChange = async () => {
    const minAge = parseInt(minAgeInput.value, 10) || 18;
    const maxAge = parseInt(maxAgeInput.value, 10) || 99;

    try {
      await chrome.storage.sync.set({ minAge, maxAge });
      console.log('Leeftijdsvoorkeur opgeslagen:', { minAge, maxAge });
    } catch (err) {
      console.error('Fout bij opslaan leeftijd:', err);
    }
  };
  minAgeInput.addEventListener('change', handleAgeChange);
  maxAgeInput.addEventListener('change', handleAgeChange);
});
