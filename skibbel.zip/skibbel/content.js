const $ = document.querySelector.bind(document);

// ---- Globale stopflag ----
window.MATCH_FOUND = window.MATCH_FOUND || false;

// ---- Hulpfuncties ----
const safeClick = (el) => {
    if (!el) return;
    ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(type => {
        el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    });
};

const isVisible = (el) => {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    return style.display !== 'none' && style.visibility !== 'hidden' && el.offsetParent !== null;
};

// ---- Storage ----
const getPreferences = async () => {
    return new Promise(resolve => {
        chrome.storage.sync.get(['gender', 'minAge', 'maxAge'], (result) => {
            const gender = Array.isArray(result.gender) ? result.gender : [];
            const minAge = result.minAge ?? 18;
            const maxAge = result.maxAge ?? 99;
            resolve({ gender, minAge, maxAge });
        });
    });
};

// ---- DOM ready ----
const awaitReadyState = () =>
    new Promise(resolve => {
        if (document.readyState === 'complete') return resolve();
        const int = setInterval(() => {
            if (document.readyState === 'complete') {
                clearInterval(int);
                resolve();
            }
        }, 10);
    });

// ---- Selectors ----
const GENDER_CLASS = '.gender';
const NEXT_BUTTON_SELECTOR = '.switch.red';
const LI4_SELECTOR = "#sendTextDiv > div > ul > li:nth-child(4)";
const OFFLINE_SELECTOR = "body > section > div > div.chatbox.card > div.card-content.messages > div.text-message.red.offline > i";

let preferredGenders = [];
let minAge = 18;
let maxAge = 99;
let nextButton;
let keyListenerAttached = false;

// ---- Key listener ----
const skipWithEscape = () => {
    if (keyListenerAttached) return;
    document.addEventListener('keyup', e => {
        if (e.key === 'Escape') {
            nextButton = nextButton || document.querySelector(NEXT_BUTTON_SELECTOR);
            safeClick(nextButton);
        }
    });
    keyListenerAttached = true;
};

// ---- Gender parsing & leeftijd ----
const parseCurrentGender = () => {
    const el = $(GENDER_CLASS);
    if (!el) return null;
    const text = (el.textContent || '').trim().toLowerCase();
    const [genderPart, agePart] = text.split(',').map(s => s.trim());
    const ageMatch = agePart ? agePart.match(/\d+/) : null;
    const age = ageMatch ? parseInt(ageMatch[0], 10) : null;
    return { gender: genderPart, age: age };
};

// ---- Skip logic ----
const handleShouldSkip = () => {
    if (!preferredGenders || preferredGenders.length === 0) return;

    const current = parseCurrentGender();
    if (!current) return;

    // ---- Leeftijd check ----
    if (current.age !== null && (current.age < minAge || current.age > maxAge)) {
        nextButton = document.querySelector(NEXT_BUTTON_SELECTOR);
        safeClick(nextButton);
        return;
    }

    // ---- Gender check ----
    const foundPreferred = preferredGenders
        .map(v => String(v).toLowerCase())
        .some(v => current.gender.startsWith(v));

    if (!foundPreferred) {
        setTimeout(() => {
            nextButton = document.querySelector(NEXT_BUTTON_SELECTOR);
            safeClick(nextButton);
        }, 30);
        return;
    }

    // ---- Match gevonden ----
    setTimeout(() => {
        const liEl = document.querySelector(LI4_SELECTOR);
        if (!isVisible(liEl)) {
            nextButton = document.querySelector(NEXT_BUTTON_SELECTOR);
            safeClick(nextButton);
        } else {
            if (!window.MATCH_FOUND) {
                console.log('[MATCH] Gender + leeftijd match gevonden.');
                window.MATCH_FOUND = true;
            }
        }

        // ---- Welcome check enkel aan het begin ----
        const welcomeEl = document.querySelector(
            "body > section > div > div.chatbox.card > div.card-content.messages > div.text-message.welcome"
        );

        if (welcomeEl) {
            const style = window.getComputedStyle(welcomeEl);
            if (style.opacity === "0" || style.display === "none") {
                // direct skip
                nextButton = document.querySelector(NEXT_BUTTON_SELECTOR);
                safeClick(nextButton);
            } else {
                // als opacity 1 is, niets doen maar pas na 0.5s uitvoeren
                setTimeout(() => {
                    // hier kan je eventueel nog extra logica toevoegen als nodig
                }, 500);
            }
        }

    }, 800);
};

// ---- Reset & herstart wanneer match weg ----
setInterval(() => {
    const liEl = document.querySelector(LI4_SELECTOR);
    if (!isVisible(liEl) && window.MATCH_FOUND) {
        console.log("[INFO] Match verdween, reset flag en zoek opnieuw.");
        window.MATCH_FOUND = false;
        nextButton = document.querySelector(NEXT_BUTTON_SELECTOR);
        safeClick(nextButton);
    }
}, 1000);

// ---- Update preferences ----
const updatePreferences = async () => {
    const prefs = await getPreferences();
    preferredGenders = prefs.gender;
    minAge = prefs.minAge;
    maxAge = prefs.maxAge;
};

// ---- Observe gender ----
const observeGender = async () => {
    let genderContainer = $(GENDER_CLASS);
    if (!genderContainer) throw new Error(GENDER_CLASS + ' not found');

    await updatePreferences();
    nextButton = document.querySelector(NEXT_BUTTON_SELECTOR);
    if (!keyListenerAttached) skipWithEscape();

    const genderObserver = new MutationObserver(() => handleShouldSkip());
    genderObserver.observe(genderContainer, { characterData: true, childList: true, subtree: true });

    const rebinder = new MutationObserver(() => {
        const currentEl = $(GENDER_CLASS);
        if (currentEl && currentEl !== genderContainer) {
            genderObserver.disconnect();
            genderContainer = currentEl;
            genderObserver.observe(genderContainer, { characterData: true, childList: true, subtree: true });
            handleShouldSkip();
        }
    });
    rebinder.observe(document.body, { childList: true, subtree: true });

    handleShouldSkip();
};

// ---- Observe app ----
const observeApp = () => {
    const app = document.querySelector('.chat-app, .skibbel-app') || document.body;
    const observer = new MutationObserver(() => {
        if ($(GENDER_CLASS) && document.querySelector(NEXT_BUTTON_SELECTOR)) {
            try {
                observeGender();
            } catch (e) {
                console.error(e);
                return;
            }
            observer.disconnect();
        }
    });
    observer.observe(app, { childList: true, subtree: true });

    if ($(GENDER_CLASS) && document.querySelector(NEXT_BUTTON_SELECTOR)) {
        observeGender();
        observer.disconnect();
    }
};

// ---- Offline check ----
setInterval(() => {
    const offlineEl = document.querySelector(OFFLINE_SELECTOR);
    if (offlineEl) {
        nextButton = document.querySelector(NEXT_BUTTON_SELECTOR);
        safeClick(nextButton);
    }
}, 2000);

// ---- Init ----
(async () => {
    await awaitReadyState();
    observeApp();
})();

// ---- Listen for storage changes ----
chrome.storage.onChanged.addListener(async changes => {
    if (changes.gender || changes.minAge || changes.maxAge) {
        await updatePreferences();
        handleShouldSkip();
    }
});
